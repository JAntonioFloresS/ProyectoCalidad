/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.Datos;
import dao.DatosRepositorio;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author anton
 */
@Named(value = "verDatos")
@RequestScoped
public class verDatos {
    private List<Datos> listaDatos = new ArrayList<Datos>();

    public List<Datos> getListaDatos() {
        return listaDatos;
    }
    
    public verDatos() {
    }
    
    @PostConstruct
    public void init(){
        
        listaDatos= DatosRepositorio.getListaDatos();
        
    }
    
}
