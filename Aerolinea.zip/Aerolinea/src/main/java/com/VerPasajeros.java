/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.Pasajero;
import dao.PasajeroRepositorio;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@Named(value = "verPasajeros")
@RequestScoped
public class VerPasajeros extends Pasajero{
    private List<Pasajero> listaPasajeros = new ArrayList<Pasajero>();

    public List<Pasajero> getListaPasajeros() {
        return listaPasajeros;
    }
    /**
     * Creates a new instance of VerPersonas
     */
    public VerPasajeros() {
    }
    
    @PostConstruct
    public void init(){
        PasajeroRepositorio pasajeroRepositorio = new PasajeroRepositorio();
        this.listaPasajeros = pasajeroRepositorio.leerPasajero();
    }
    
}