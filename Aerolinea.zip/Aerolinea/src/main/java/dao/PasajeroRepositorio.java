/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anton
 */
public class PasajeroRepositorio {
    public int obtenerIdPersona(){
        int idPersona = 1;
        try{
            String consulta = "SELECT IDPERSONA FROM PERSONA ORDER BY IDPERSONA DESC FETCH FIRST ROW ONLY";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next() != false){
                idPersona = rs.getInt("IDPERSONA");
                idPersona += 1;
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return idPersona;
    }
    
    public Boolean crearPasajero(Pasajero pasajero){
        try{
            String consulta = "INSERT INTO PERSONA (IDPERSONA, NOMBRE, APELLIDO1, APELLIDO2,"
                    + " IDENTIFICACION) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            sentencia.setInt(1, obtenerIdPersona());
            sentencia.setString(2, pasajero.getNombre());
            sentencia.setString(3, pasajero.getApellidos());
            sentencia.setString(4, pasajero.getAsiento());
            sentencia.setString(5, pasajero.getIdentificacion());
            sentencia.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }
    
    public Pasajero leerPasajero(String identificacion){
        Pasajero pasajero = null;
        try{
            String consulta = "SELECT IDPERSONA, NOMBRE, APELLIDO1, APELLIDO2,"
                    + " IDENTIFICACION FROM PERSONA WHERE IDENTIFICACION = ?";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            sentencia.setString(1, identificacion);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                pasajero = new Pasajero();
                pasajero.setIdPersona(rs.getInt("IDPERSONA"));
                pasajero.setNombre(rs.getString("NOMBRE"));
                pasajero.setApellidos(rs.getString("APELLIDO1"));
                pasajero.setAsiento(rs.getString("APELLIDO2"));
                pasajero.setIdentificacion(rs.getString("IDENTIFICACION"));
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return pasajero;
    }
    
    public List<Pasajero> leerPasajero(){
        List<Pasajero> listaPasajeros = new ArrayList<>();
        try{
            String consulta = "SELECT IDPERSONA, NOMBRE, APELLIDO1, APELLIDO2,"
                    + " IDENTIFICACION FROM PERSONA";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            ResultSet rs = sentencia.executeQuery();
            while(rs.next()){
                Pasajero pasajero = new Pasajero();
                pasajero.setIdPersona(rs.getInt("IDPERSONA"));
                pasajero.setNombre(rs.getString("NOMBRE"));
                pasajero.setApellidos(rs.getString("APELLIDO1"));
                pasajero.setAsiento(rs.getString("APELLIDO2"));
                pasajero.setIdentificacion(rs.getString("IDENTIFICACION"));
                listaPasajeros.add(pasajero);
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return listaPasajeros;
    }
    
    public Boolean actualizarPasajero(Pasajero pasajero){
        try{
            String consulta = "UPDATE PERSONA SET NOMBRE = ?, APELLIDO1 = ?, APELLIDO2 = ?,"
                    + " IDENTIFICACION = ? WHERE IDPERSONA = ?";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            sentencia.setString(1, pasajero.getNombre());
            sentencia.setString(2, pasajero.getApellidos());
            sentencia.setString(3, pasajero.getAsiento());
            sentencia.setString(4, pasajero.getIdentificacion());
            sentencia.setInt(5, pasajero.getIdPersona());
            sentencia.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }
    
    public Boolean eliminarPasajero(Pasajero pasajero){
        try{
            String consulta = "DELETE FROM PERSONA WHERE IDPERSONA = ?";
            PreparedStatement sentencia = Conexion.getConexion().prepareStatement(consulta);
            sentencia.setInt(1, pasajero.getIdPersona());
            sentencia.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }  
}
