/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anton
 */
public class DatosRepositorio {
    private static List<Datos> listaDatos = new ArrayList<>();

    public static List<Datos> getListaDatos() {
        return listaDatos;
    }

    public static void setListaDatos(List<Datos> listaDatos) {
        DatosRepositorio.listaDatos = listaDatos;
    }
    
    public static void agregarDatos(Datos datos){
        listaDatos.add(datos);
    }
    
    public static boolean existeDato(String email){
        for(Datos datos : listaDatos){
            if(datos.getEmail().equals(email))
                return true;
        }
        return false;
    }
    
}
