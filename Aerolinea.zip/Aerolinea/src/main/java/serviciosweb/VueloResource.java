/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviciosweb;

import dao.Vuelo;
import dao.VueloRepositorio;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.enterprise.context.RequestScoped;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author anton
 */
@Path("vuelo")
@RequestScoped
public class VueloResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of VueloResource
     */
    public VueloResource() {
    }

    /**
     * Retrieves representation of an instance of serviciosweb.VueloResource
     * @return an instance of java.lang.String
     */
    @GET
    @Path("/ping")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerPing() {
        return Response.ok("{\"ping\": 1}").build();
    }
    
    @GET
    @Path("/vuelos")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVuelos(){
        try{
            List<Vuelo> listaVuelo = VueloRepositorio.getListaVuelos();
            JsonArrayBuilder arregloVuelos = Json.createArrayBuilder();
            for(Vuelo vuelo: listaVuelo){
                JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
                JsonObject jsonObject = jsonObjectBuilder
                        .add("paisSalida", vuelo.getPaisSalida())
                        .add("paisLlegada", vuelo.getPaisLlegada())
                        .add("fechaIda", vuelo.getFechaIda())
                        .add("fechaRegreso", vuelo.getFechaRegreso())
                        .add("pasajero", vuelo.getPasajero())
                        .add("clase", vuelo.getClase())
                        .build();
                arregloVuelos.add(jsonObject);
            }
            JsonObjectBuilder jsonObjectBuilder2 = Json.createObjectBuilder();
            JsonObject jsonFinal = jsonObjectBuilder2.add("vuelos", arregloVuelos).build();
            StringWriter jsonString = new StringWriter();
            JsonWriter jsonWriter = Json.createWriter(jsonString);
            jsonWriter.writeObject(jsonFinal);
            return Response.ok(jsonString.toString()).build();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            String resultado = "{\"error\": \"Ocurrio un error inesperado\"}";
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(resultado).build();           
        }
    }
    
    @POST
    @Path("/agregarVuelo")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response ingresarVuelo(String content){
        try{
            JsonObject jsonObject;
            JsonReader jsonReader = Json.createReader(new StringReader(content));
            jsonObject = jsonReader.readObject();
            
            Vuelo vuelo = new Vuelo();
            vuelo.setPaisSalida(jsonObject.getString("paisSalida"));
            vuelo.setPaisLlegada(jsonObject.getString("paisLlegada"));
            vuelo.setFechaIda(jsonObject.getString("fechaIda"));
            vuelo.setFechaRegreso(jsonObject.getString("fechaRegreso"));;
            vuelo.setPasajero(jsonObject.getString("pasajero"));
            vuelo.setClase(jsonObject.getString("clase"));
            VueloRepositorio.agregarListaVuelos(vuelo);
            return Response.ok("{\"operacionExitosa\":1 }").build();
            
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            String resultado = "{\"error\": \"Ocurrio un error inesperado\"}";
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(resultado).build();           
        }       
    }
       
}
