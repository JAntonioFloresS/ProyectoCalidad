/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.Pasajero;
import dao.PasajeroRepositorio;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@Named(value = "buscar")
@RequestScoped
public class Buscar extends Pasajero{
    private PasajeroRepositorio pasajeroRepositorio = new PasajeroRepositorio();
    private String identificacionBuscar;

    public String getIdentificacionBuscar() {
        return identificacionBuscar;
    }

    public void setIdentificacionBuscar(String identificacionBuscar) {
        this.identificacionBuscar = identificacionBuscar;
    }

    /**
     * Creates a new instance of Buscar
     */
    public Buscar() {
    }
    
    public String buscarIdentificacion(){
        Pasajero pasajero = pasajeroRepositorio.leerPasajero(this.getIdentificacionBuscar());
        this.setIdPersona(pasajero.getIdPersona());
        this.setNombre(pasajero.getNombre());
        this.setApellidos(pasajero.getApellidos());
        this.setAsiento(pasajero.getAsiento());
        this.setIdentificacion(pasajero.getIdentificacion());
        this.setIdentificacionBuscar("");
        return "buscar";
    }
    
    public String eliminarPasajero(){
        pasajeroRepositorio.eliminarPasajero(this);
        return "buscar";
    }
    
    public String actualizarPasajero(){
        pasajeroRepositorio.actualizarPasajero(this);
        return "buscar";
    }
}
