/* global i */

function funcion(mensaje){
    alert(mensaje);  
}

function guardar(){
    var paisSalida = document.getElementById("paisSalida").value;
    var paisLlegada = document.getElementById("paisLlegada").value;
    var fechaIda = document.getElementById("fechaIda").value;
    var fechaRegreso = document.getElementById("fechaRegreso").value;
    var pasajero = document.getElementById("pasajero").value;
    var clase = document.getElementById("clase").value;
    
    var jsonParametro = {"paisSalida": paisSalida,"paisLlegada": paisLlegada,"fechaIda":fechaIda,
        "fechaRegreso":fechaRegreso,"pasajero": pasajero, "clase": clase};
    
    $.ajax({
        type: "POST",
        url: "http://localhost:8080/Aerolinea/miApi/vuelo/agregarVuelo",
        data: JSON.stringify(jsonParametro),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data){
            if(parseInt(data.operacionExitosa)===1){
                document.getElementById("paisSalida").value = "";
                document.getElementById("paisLlegada").value = "";
                document.getElementById("fechaIda").value = "";
                document.getElementById("fechaRegreso").value = "";
                document.getElementById("pasajero").value = "";
                document.getElementById("clase").value = "";               
            }
            else 
                alert("Ocurrio un error inesperado");
        }
    });
}

function cargar(){
    $.get("http://localhost:8080/Aerolinea/miApi/vuelo/vuelos", function(data, status){
        var vuelos = data.vuelos;
        var vuelosString = "";
        for(i in vuelos){
            vuelosString += "Desde: " + vuelos[i].paisSalida + " Hacia: " + vuelos[i].paisLlegada +
                    " Fecha de Ida: " + vuelos[i].fechaIda + " Fecha de Regreso: " + vuelos[i].fechaRegreso+
                    " Pasajero: " + vuelos[i].pasajero + " Clase: " + vuelos[i].clase + "\n";                    
        }
        $("#resultado").val(vuelosString);
    });
}

