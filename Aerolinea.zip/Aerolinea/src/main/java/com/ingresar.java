package com;

import dao.Datos;
import dao.DatosRepositorio;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
/**
 *
 * @author anton
 */
@Named(value = "ingresar")
@RequestScoped
public class ingresar extends Datos{
    private String mensaje;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    /**
     * Creates a new instance of ingresar
     */
    public ingresar() {
    }
    
    public String guardarDatos(){
        DatosRepositorio.agregarDatos(this);
        return "verDatos";
    }
    
    public void validar(){
        String email  = this.getEmail();
        if(DatosRepositorio.existeDato(email)){
            this.mensaje = "este dato ya esta registrado";
        }
    }
}    
