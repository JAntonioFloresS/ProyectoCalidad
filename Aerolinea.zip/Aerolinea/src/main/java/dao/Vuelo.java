package dao;
/**
 *
 * @author anton
 */
public class Vuelo {
    private String paisSalida;
    private String paisLlegada;
    private String fechaIda;
    private String fechaRegreso;
    private String pasajero;
    private String clase;

    public String getPaisSalida() {
        return paisSalida;
    }

    public void setPaisSalida(String paisSalida) {
        this.paisSalida = paisSalida;
    }

    public String getPaisLlegada() {
        return paisLlegada;
    }

    public void setPaisLlegada(String paisLlegada) {
        this.paisLlegada = paisLlegada;
    }

    public String getFechaIda() {
        return fechaIda;
    }

    public void setFechaIda(String fechaIda) {
        this.fechaIda = fechaIda;
    }

    public String getFechaRegreso() {
        return fechaRegreso;
    }

    public void setFechaRegreso(String fechaRegreso) {
        this.fechaRegreso = fechaRegreso;
    }

    public String getPasajero() {
        return pasajero;
    }

    public void setPasajero(String pasajero) {
        this.pasajero = pasajero;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

  
}
